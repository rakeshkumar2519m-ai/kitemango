// @polsia:user-owned — receipt-only confirmation page for the public client brief.
import type { Metadata } from 'next';
import { BriefConfirmation } from '@/components/custom/brief-confirmation';

export const metadata: Metadata = {
  title: 'Brief received',
  description: 'Confirmation that your KiteMango client brief was received.',
  referrer: 'no-referrer',
  robots: { index: false, follow: false },
};

export default async function BriefConfirmationPage({
  params,
}: {
  params: Promise<{ receipt: string }>;
}) {
  const { receipt } = await params;
  return <BriefConfirmation receipt={receipt} />;
}
