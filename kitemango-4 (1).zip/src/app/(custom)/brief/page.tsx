// @polsia:user-owned — public KiteMango client brief page.
import type { Metadata } from 'next';
import { BriefForm } from '@/components/custom/brief-form';

export const metadata: Metadata = {
  title: 'Start a client brief',
  description: 'Share your local business goals and content needs with KiteMango.',
};

export default function BriefPage() {
  return (
    <main className="mx-auto w-full max-w-5xl px-4 py-10 sm:px-6 sm:py-16 lg:px-8">
      <div className="grid gap-8 lg:grid-cols-[0.7fr_1.3fr] lg:gap-12">
        <header className="lg:sticky lg:top-24 lg:self-start">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-primary">
            KiteMango · Client brief
          </p>
          <h1 className="mt-4 text-4xl font-bold leading-tight tracking-[-0.04em] sm:text-5xl">
            Tell us what your business needs next.
          </h1>
          <p className="mt-5 leading-7 text-muted-foreground">
            A few practical details help us understand your business, audience, channels, and the
            content you have in mind.
          </p>
          <p className="mt-6 rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm leading-6 text-foreground">
            Your brief is saved privately. After submitting, keep the confirmation link to return to
            your acknowledgment.
          </p>
        </header>
        <BriefForm />
      </div>
    </main>
  );
}
