// @polsia:user-owned — public KiteMango services and sample pricing page.

import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Clapperboard,
  FileImage,
  Globe2,
  Megaphone,
  Sparkles,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export const metadata: Metadata = {
  title: 'Services and pricing for local businesses',
  description:
    'Explore KiteMango sample prices for social media content and promotional reels, with posters and simple websites available as optional services.',
  alternates: { canonical: '/pricing' },
};

const coreServices = [
  {
    name: 'Social media content',
    icon: Megaphone,
    price: '₹4,999',
    unit: 'sample starting price · monthly',
    description:
      'A practical set of social content, captions, and campaign ideas shaped around your business and chosen channels.',
    details: ['Posts and captions', 'Channel-aware content ideas', 'Scope agreed from your brief'],
    featured: true,
  },
  {
    name: 'Promotional reels',
    icon: Clapperboard,
    price: '₹2,499',
    unit: 'sample starting price · per reel',
    description:
      'Short-form promotional video concepts and edits to help put a product, service, or local offer in the spotlight.',
    details: [
      'Promotion-first creative direction',
      'Built around assets you can share',
      'Final scope agreed from your brief',
    ],
    featured: false,
  },
] as const;

const optionalServices = [
  {
    name: 'Offer posters',
    icon: FileImage,
    price: '₹799',
    unit: 'sample starting price · per poster',
    description: 'A focused poster for a promotion, event, new arrival, or seasonal message.',
  },
  {
    name: 'Simple websites',
    icon: Globe2,
    price: '₹14,999',
    unit: 'sample starting price · per project',
    description:
      'A straightforward web presence for sharing what you do and how customers can reach you.',
  },
] as const;

function BriefButton({ children }: { children: React.ReactNode }) {
  return (
    <Button
      asChild
      size="lg"
      className="min-h-12 rounded-full px-6 text-base shadow-md shadow-primary/15"
    >
      <Link href="/brief">
        {children}
        <ArrowRight aria-hidden="true" />
      </Link>
    </Button>
  );
}

export default function PricingPage() {
  return (
    <main className="overflow-hidden">
      <section className="relative border-b border-border" aria-labelledby="pricing-heading">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[34rem] bg-gradient-to-br from-primary/20 via-background to-accent/25"
          aria-hidden="true"
        />
        <div className="mx-auto grid max-w-screen-xl gap-10 px-4 pb-14 pt-12 sm:px-6 sm:pb-20 sm:pt-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:gap-16 lg:px-8 lg:pb-24 lg:pt-20">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-background/80 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-primary sm:text-sm">
              <Sparkles className="size-4" aria-hidden="true" />
              Services &amp; sample prices · INR
            </p>
            <h1
              id="pricing-heading"
              className="mt-6 max-w-3xl text-4xl font-bold leading-[1.03] tracking-[-0.045em] text-foreground sm:text-6xl lg:text-7xl"
            >
              Make your next local offer hard to scroll past.
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-7 text-muted-foreground sm:text-lg sm:leading-8">
              Start with social media content and promotional reels for your shop or service
              business. Add a poster or simple website when it fits the campaign.
            </p>
            <div className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <BriefButton>Start your client brief</BriefButton>
              <Link
                href="#core-services"
                className="inline-flex min-h-11 items-center gap-2 rounded-full px-2 text-sm font-semibold text-foreground underline-offset-4 hover:underline"
              >
                Compare services <ArrowUpRight className="size-4" aria-hidden="true" />
              </Link>
            </div>
            <p className="mt-5 max-w-xl text-sm leading-6 text-muted-foreground">
              Sending a brief is free. It goes straight to the client brief form; there is no
              checkout or payment step.
            </p>
          </div>

          <aside
            className="relative mx-auto w-full max-w-lg"
            aria-label="KiteMango service overview"
          >
            <div
              className="absolute -left-5 top-8 size-24 rounded-full bg-accent/40 blur-2xl sm:-left-8 sm:size-36"
              aria-hidden="true"
            />
            <div
              className="absolute -right-2 bottom-5 size-28 rounded-full bg-primary/25 blur-2xl sm:-right-6 sm:size-40"
              aria-hidden="true"
            />
            <div className="relative rounded-[1.75rem] border border-primary/20 bg-card/90 p-5 shadow-xl shadow-primary/10 backdrop-blur sm:p-7">
              <div className="flex items-center justify-between gap-3 border-b border-border pb-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                    A clear place to start
                  </p>
                  <p className="mt-1 text-lg font-semibold">Pick the campaign support you need</p>
                </div>
                <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Sparkles className="size-5" aria-hidden="true" />
                </span>
              </div>
              <ul className="mt-5 space-y-3">
                {[
                  'Lead with social content and reels',
                  'Add posters or a simple website if useful',
                  'Share the details once in one short brief',
                ].map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-3 text-sm leading-6 text-muted-foreground"
                  >
                    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                      <Check className="size-3.5" aria-hidden="true" />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-6 rounded-2xl bg-muted/70 p-4 sm:p-5">
                <p className="text-sm font-semibold">No payment to send a brief</p>
                <p className="mt-1 text-sm leading-6 text-muted-foreground">
                  Tell KiteMango what your business needs. Your submission ends with a private
                  receipt confirmation.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <section
        id="core-services"
        className="mx-auto max-w-screen-xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8"
        aria-labelledby="core-services-heading"
      >
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-primary">
            Core services
          </p>
          <h2
            id="core-services-heading"
            className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl"
          >
            Build a steady local presence.
          </h2>
          <p className="mt-4 leading-7 text-muted-foreground">
            Social media content and promotional reels are the main ways to get started.
          </p>
        </div>
        <div className="mt-9 grid gap-5 lg:grid-cols-2 lg:gap-6">
          {coreServices.map((service) => {
            const Icon = service.icon;
            return (
              <article
                key={service.name}
                className={`relative flex h-full flex-col rounded-3xl border p-5 shadow-sm sm:p-7 ${service.featured ? 'border-primary/45 bg-card shadow-primary/10' : 'border-border bg-card/80'}`}
              >
                {service.featured ? (
                  <span className="absolute right-4 top-4 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary sm:right-6 sm:top-6">
                    Primary service
                  </span>
                ) : null}
                <div className="flex size-12 items-center justify-center rounded-2xl bg-accent/70 text-accent-foreground">
                  <Icon className="size-6" aria-hidden="true" />
                </div>
                <h3 className="mt-5 text-xl font-bold tracking-tight sm:text-2xl">
                  {service.name}
                </h3>
                <p className="mt-3 max-w-xl leading-7 text-muted-foreground">
                  {service.description}
                </p>
                <div className="mt-6 rounded-2xl bg-muted/65 p-4 sm:p-5">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                    Sample starting price
                  </p>
                  <p className="mt-1 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                    {service.price}
                    <span className="ml-2 text-sm font-medium tracking-normal text-muted-foreground">
                      INR
                    </span>
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {service.unit.replace('sample starting price · ', '')}
                  </p>
                </div>
                <ul className="mt-5 space-y-2.5">
                  {service.details.map((detail) => (
                    <li
                      key={detail}
                      className="flex items-start gap-2.5 text-sm leading-6 text-muted-foreground"
                    >
                      <Check className="mt-1 size-4 shrink-0 text-primary" aria-hidden="true" />
                      {detail}
                    </li>
                  ))}
                </ul>
                <div className="mt-auto pt-6">
                  <Button
                    asChild
                    variant={service.featured ? 'default' : 'outline'}
                    className="min-h-11 w-full rounded-full"
                  >
                    <Link href="/brief">
                      Ask about {service.name.toLowerCase()} <ArrowRight aria-hidden="true" />
                    </Link>
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
        <p className="mx-auto mt-6 max-w-3xl text-center text-sm leading-6 text-muted-foreground">
          These are proposed sample prices and example starting scopes, not verified or final
          quotes. KiteMango can confirm the right scope and price after reviewing your brief.
        </p>
      </section>

      <section
        className="border-y border-border bg-muted/35"
        aria-labelledby="optional-services-heading"
      >
        <div className="mx-auto max-w-screen-xl px-4 py-14 sm:px-6 sm:py-18 lg:px-8">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-primary">
                Optional add-ons
              </p>
              <h2
                id="optional-services-heading"
                className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl"
              >
                Extra pieces for the campaign.
              </h2>
            </div>
            <p className="max-w-xl leading-7 text-muted-foreground">
              Posters and simple websites are available when your business needs more than social
              content.
            </p>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {optionalServices.map((service) => {
              const Icon = service.icon;
              return (
                <article
                  key={service.name}
                  className="rounded-2xl border border-border bg-card p-5 sm:p-6"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold">{service.name}</h3>
                      <p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">
                        {service.description}
                      </p>
                    </div>
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Icon className="size-5" aria-hidden="true" />
                    </span>
                  </div>
                  <p className="mt-5 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                    Sample starting price
                  </p>
                  <p className="mt-1 text-2xl font-bold tracking-tight">
                    {service.price}{' '}
                    <span className="text-sm font-medium text-muted-foreground">INR</span>
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {service.unit.replace('sample starting price · ', '')}
                  </p>
                  <Link
                    href="/brief"
                    className="mt-4 inline-flex min-h-10 items-center gap-2 text-sm font-semibold text-primary underline-offset-4 hover:underline"
                  >
                    Add to your brief <ArrowUpRight className="size-4" aria-hidden="true" />
                  </Link>
                </article>
              );
            })}
          </div>
          <div className="mt-10 flex flex-col items-start justify-between gap-5 rounded-3xl bg-foreground px-5 py-7 text-background sm:flex-row sm:items-center sm:px-8">
            <div className="flex items-start gap-4">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-background/10 text-background">
                <Sparkles className="size-5" aria-hidden="true" />
              </span>
              <div>
                <h3 className="text-xl font-semibold">Tell us what you have in mind.</h3>
                <p className="mt-1 max-w-xl text-sm leading-6 text-background/75">
                  Share your goals, channels, and timing in the client brief. It is free to submit,
                  with no payment step.
                </p>
              </div>
            </div>
            <BriefButton>Go to the client brief</BriefButton>
          </div>
        </div>
      </section>
    </main>
  );
}
