// @polsia:user-owned — the public home page for KiteMango.

import { ArrowDownRight, ArrowUpRight, Check, Clapperboard, Globe2, Sparkles } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteDescription, siteName } from '@/lib/brand';

export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  alternates: { canonical: '/' },
};

export default function HomePage() {
  return (
    <main className="overflow-hidden">
      <section className="relative border-b border-border" aria-labelledby="hero-heading">
        <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[34rem] bg-gradient-to-br from-primary/20 via-background to-accent/20" />
        <div className="mx-auto grid max-w-screen-xl gap-12 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-12 lg:gap-8 lg:px-8 lg:pb-28 lg:pt-24">
          <div className="flex flex-col justify-center lg:col-span-7 lg:pr-10">
            <Badge
              variant="outline"
              className="mb-7 w-fit gap-2 border-primary/40 bg-background/70 px-3 py-1.5 text-primary"
            >
              <span className="size-2 rounded-full bg-primary" aria-hidden="true" />
              For India&apos;s local shops and service businesses
            </Badge>
            <h1
              id="hero-heading"
              className="max-w-4xl text-5xl font-bold leading-[0.98] tracking-[-0.05em] text-foreground sm:text-7xl lg:text-[6.5rem]"
            >
              Make your next post feel like a busy street.
            </h1>
            <p className="mt-7 max-w-xl text-lg leading-8 text-muted-foreground sm:text-xl">
              {siteDescription}. KiteMango turns what you know about your business into
              ready-to-publish posts, captions, and promotional reels — without asking you to become
              a designer, editor, or AI expert.
            </p>
            <div className="mt-9 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <Button
                asChild
                size="lg"
                className="h-12 rounded-full px-7 text-base shadow-lg shadow-primary/20 transition-transform duration-200 ease-out hover:-translate-y-1"
              >
                <Link href="/brief">
                  Start your client brief
                  <ArrowUpRight aria-hidden="true" />
                </Link>
              </Button>
              <Button asChild variant="link" className="h-12 px-0 text-foreground">
                <Link href="#services">
                  See what gets made
                  <ArrowDownRight aria-hidden="true" />
                </Link>
              </Button>
            </div>
            <p className="mt-7 text-sm text-muted-foreground">
              Start with social content and reels. Add a poster or simple website when your next
              campaign needs it.
            </p>
          </div>

          <div className="relative flex min-h-[30rem] items-center justify-center lg:col-span-5 lg:min-h-[39rem]">
            <div
              className="absolute right-4 top-2 h-56 w-56 rounded-full bg-accent/25 blur-3xl sm:right-12"
              aria-hidden="true"
            />
            <Card className="relative w-full max-w-md rotate-2 overflow-hidden border-primary/30 bg-card/90 shadow-2xl shadow-primary/15 backdrop-blur transition-transform duration-300 ease-out hover:rotate-0">
              <div className="flex items-center justify-between border-b border-border px-5 py-4">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <span
                    className="flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground"
                    aria-hidden="true"
                  >
                    <Sparkles className="size-4" />
                  </span>
                  KiteMango brief
                </div>
                <span className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
                  01 / 03
                </span>
              </div>
              <CardContent className="p-0">
                <div className="relative aspect-[4/5] overflow-hidden bg-gradient-to-br from-primary/90 via-primary/70 to-accent/70 p-6 text-primary-foreground sm:p-8">
                  <svg
                    className="absolute -right-10 -top-8 size-52 opacity-30"
                    viewBox="0 0 220 220"
                    fill="none"
                    aria-hidden="true"
                  >
                    <circle cx="110" cy="110" r="88" stroke="currentColor" strokeWidth="22" />
                    <path
                      d="M110 22c31 21 52 52 55 88-26-7-49-25-65-51-9-15-9-25 10-37Z"
                      fill="currentColor"
                    />
                  </svg>
                  <div className="relative flex h-full flex-col justify-between">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.2em]">Fresh drop</p>
                      <p className="mt-4 max-w-[12rem] text-4xl font-bold leading-none tracking-[-0.06em] sm:text-5xl">
                        Your neighbourhood&apos;s new favourite.
                      </p>
                    </div>
                    <div className="flex items-end justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium opacity-80">For your next</p>
                        <p className="text-2xl font-semibold">weekend offer</p>
                      </div>
                      <div className="flex size-16 rotate-[-12deg] items-center justify-center rounded-full bg-card text-center text-xs font-bold uppercase leading-tight text-card-foreground shadow-lg">
                        Made
                        <br />
                        to share
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 p-5">
                  <p className="max-w-[15rem] text-sm leading-6 text-muted-foreground">
                    One clear idea, shaped into a post your customers can actually notice.
                  </p>
                  <ArrowUpRight className="size-5 shrink-0 text-primary" aria-hidden="true" />
                </div>
              </CardContent>
            </Card>
            <div className="absolute -bottom-1 left-0 hidden w-48 -rotate-6 border border-border bg-muted p-4 shadow-xl sm:block lg:left-[-1.5rem]">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                Built for
              </p>
              <p className="mt-2 text-lg font-semibold leading-tight text-foreground">
                The business behind the counter.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section
        id="services"
        className="mx-auto max-w-screen-xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28"
        aria-labelledby="services-heading"
      >
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">
              The useful bit
            </p>
            <h2
              id="services-heading"
              className="mt-5 max-w-md text-4xl font-bold leading-tight tracking-[-0.04em] sm:text-5xl"
            >
              Your work is local. Your presence should feel alive.
            </h2>
            <p className="mt-6 max-w-md text-base leading-7 text-muted-foreground">
              You bring the real offer, the real audience, and the local know-how. KiteMango brings
              the creative lift to help more people find it.
            </p>
          </div>
          <div className="divide-y divide-border border-y border-border">
            <Card className="group rounded-none border-0 border-b border-border bg-transparent shadow-none transition-colors duration-200 hover:bg-muted/60">
              <CardContent className="grid gap-5 px-0 py-7 sm:grid-cols-[4rem_1fr_auto] sm:items-start sm:gap-7">
                <span className="text-2xl font-semibold tracking-[-0.04em] text-primary">01</span>
                <div>
                  <h3 className="text-2xl font-semibold tracking-[-0.03em]">
                    Social content that sounds like you
                  </h3>
                  <p className="mt-2 max-w-xl leading-7 text-muted-foreground">
                    A steady stream of social posts and captions shaped around your business, your
                    offers, and the customers you want to welcome next.
                  </p>
                </div>
                <Sparkles
                  className="hidden size-6 text-primary transition-transform duration-200 group-hover:rotate-12 sm:block"
                  aria-hidden="true"
                />
              </CardContent>
            </Card>
            <Card className="group rounded-none border-0 border-b border-border bg-transparent shadow-none transition-colors duration-200 hover:bg-muted/60">
              <CardContent className="grid gap-5 px-0 py-7 sm:grid-cols-[4rem_1fr_auto] sm:items-start sm:gap-7">
                <span className="text-2xl font-semibold tracking-[-0.04em] text-primary">02</span>
                <div>
                  <h3 className="text-2xl font-semibold tracking-[-0.03em]">
                    Promotional reels people can feel
                  </h3>
                  <p className="mt-2 max-w-xl leading-7 text-muted-foreground">
                    Short, energetic business videos that turn a product, service, or seasonal offer
                    into a reason to stop scrolling.
                  </p>
                </div>
                <Clapperboard
                  className="hidden size-6 text-primary transition-transform duration-200 group-hover:rotate-6 sm:block"
                  aria-hidden="true"
                />
              </CardContent>
            </Card>
            <Card className="group rounded-none border-0 bg-transparent shadow-none transition-colors duration-200 hover:bg-muted/60">
              <CardContent className="grid gap-5 px-0 py-7 sm:grid-cols-[4rem_1fr_auto] sm:items-start sm:gap-7">
                <span className="text-2xl font-semibold tracking-[-0.04em] text-primary">03</span>
                <div>
                  <h3 className="text-2xl font-semibold tracking-[-0.03em]">
                    The extras when a campaign grows
                  </h3>
                  <p className="mt-2 max-w-xl leading-7 text-muted-foreground">
                    Need a campaign poster or a simple website too? Add the right supporting piece
                    without learning another tool.
                  </p>
                </div>
                <Globe2
                  className="hidden size-6 text-primary transition-transform duration-200 group-hover:-rotate-6 sm:block"
                  aria-hidden="true"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section
        id="process"
        className="border-y border-border bg-muted/50"
        aria-labelledby="process-heading"
      >
        <div className="mx-auto max-w-screen-xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">
                A lighter way to market
              </p>
              <h2
                id="process-heading"
                className="mt-5 max-w-2xl text-4xl font-bold leading-tight tracking-[-0.04em] sm:text-5xl"
              >
                From what you know to what your customers see.
              </h2>
            </div>
            <p className="max-w-sm leading-7 text-muted-foreground">
              No complicated dashboard. No design homework. Just a clear creative brief and useful
              content ready for your channels.
            </p>
          </div>
          <ol className="mt-14 grid gap-0 border-t border-border md:grid-cols-3">
            {[
              [
                '01',
                'Tell us what is happening',
                'Share the offer, moment, product, or service you want people to notice.',
              ],
              [
                '02',
                'We shape the idea',
                'KiteMango turns your direction into a small set of clear, on-brand creative pieces.',
              ],
              [
                '03',
                'You publish with confidence',
                'Get ready-to-use content for the places your customers already spend time.',
              ],
            ].map(([number, title, description]) => (
              <li
                key={number}
                className="border-b border-border py-7 md:border-b-0 md:border-r md:px-7 md:first:pl-0 md:last:border-r-0"
              >
                <span className="text-sm font-semibold text-primary">{number}</span>
                <h3 className="mt-8 max-w-xs text-2xl font-semibold leading-tight tracking-[-0.03em]">
                  {title}
                </h3>
                <p className="mt-4 max-w-xs leading-7 text-muted-foreground">{description}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section
        id="why"
        className="mx-auto max-w-screen-xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28"
        aria-labelledby="why-heading"
      >
        <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div className="relative overflow-hidden rounded-[2rem] bg-primary p-8 text-primary-foreground sm:p-12 lg:min-h-[24rem]">
            <div
              className="absolute -bottom-24 -right-12 size-64 rounded-full border-[2rem] border-primary-foreground/15"
              aria-hidden="true"
            />
            <div className="relative flex h-full flex-col justify-between gap-16">
              <p className="max-w-xs text-sm font-semibold uppercase tracking-[0.2em]">
                Small business, big presence
              </p>
              <p className="max-w-xl text-3xl font-semibold leading-tight tracking-[-0.04em] sm:text-4xl">
                “The best marketing is often just a good reason to be remembered.”
              </p>
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">
              Why KiteMango
            </p>
            <h2
              id="why-heading"
              className="mt-5 text-4xl font-bold leading-tight tracking-[-0.04em] sm:text-5xl"
            >
              Creative help, without the creative-industry fog.
            </h2>
            <ul className="mt-8 space-y-5">
              {[
                'Made for busy owners, not full-time marketers.',
                'Built around your actual offer and local audience.',
                'Useful pieces you can publish, share, and build on.',
              ].map((item) => (
                <li key={item} className="flex gap-3 leading-7 text-muted-foreground">
                  <Check className="mt-1 size-5 shrink-0 text-primary" aria-hidden="true" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section id="contact" className="border-t border-border" aria-labelledby="contact-heading">
        <div className="mx-auto flex max-w-screen-xl flex-col gap-8 px-4 py-20 sm:px-6 md:flex-row md:items-end md:justify-between lg:px-8 lg:py-28">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">
              Ready when you are
            </p>
            <h2
              id="contact-heading"
              className="mt-5 max-w-2xl text-4xl font-bold leading-tight tracking-[-0.04em] sm:text-6xl"
            >
              Give your next good idea somewhere to go.
            </h2>
            <p className="mt-5 max-w-xl leading-7 text-muted-foreground">
              Share your business, goals, channels, content needs, available reel assets, and timing
              in one short brief.
            </p>
          </div>
          <div className="shrink-0">
            <Button
              asChild
              size="lg"
              className="h-12 rounded-full px-7 text-base transition-transform duration-200 ease-out hover:-translate-y-1"
            >
              <Link href="/brief">
                Start a client brief
                <ArrowUpRight aria-hidden="true" />
              </Link>
            </Button>
            <p className="mt-4 text-right text-sm text-muted-foreground">kitemango-4@polsia.app</p>
          </div>
        </div>
      </section>
    </main>
  );
}
