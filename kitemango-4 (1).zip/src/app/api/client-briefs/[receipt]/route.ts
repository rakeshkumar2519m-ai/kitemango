// @polsia:user-owned — receipt-only lookup; this endpoint never returns brief details.
import 'server-only';
import { createHash } from 'node:crypto';
import { NextResponse } from 'next/server';
import { ClientBriefAcknowledgement } from '@/lib/contracts/client-brief';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(_request: Request, context: { params: Promise<{ receipt: string }> }) {
  const { receipt } = await context.params;
  if (!/^[a-f0-9]{64}$/.test(receipt)) {
    return NextResponse.json({ error: 'Confirmation not found.' }, { status: 404 });
  }

  const receiptHash = createHash('sha256').update(receipt).digest('hex');
  const brief = await prisma.clientBrief.findUnique({
    where: { receiptHash },
    select: { createdAt: true },
  });

  if (!brief) {
    return NextResponse.json({ error: 'Confirmation not found.' }, { status: 404 });
  }

  return NextResponse.json(
    ClientBriefAcknowledgement.parse({
      acknowledged: true,
      submittedAt: brief.createdAt.toISOString(),
    }),
    { headers: { 'Cache-Control': 'no-store' } },
  );
}
