// @polsia:user-owned — public write endpoint for KiteMango client briefs.
import 'server-only';
import { createHash, randomBytes } from 'node:crypto';
import { NextResponse } from 'next/server';
import { ClientBriefCreate, ClientBriefReceipt } from '@/lib/contracts/client-brief';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ errors: { form: 'Submit a valid brief.' } }, { status: 400 });
  }

  const parsed = ClientBriefCreate.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    const flattened = parsed.error.flatten();
    for (const [field, messages] of Object.entries(flattened.fieldErrors)) {
      const message = messages?.[0];
      if (message) errors[field] = message;
    }
    if (Object.keys(errors).length === 0) {
      errors.form = flattened.formErrors[0] ?? 'Review the brief and try again.';
    }
    return NextResponse.json({ errors }, { status: 400 });
  }

  try {
    const receipt = randomBytes(32).toString('hex');
    const receiptHash = createHash('sha256').update(receipt).digest('hex');
    const brief = parsed.data;

    await prisma.clientBrief.create({
      data: {
        ...brief,
        receiptHash,
        reelAssetNotes: brief.reelAssetNotes || null,
        reelAssetLink: brief.reelAssetLink || null,
        additionalNotes: brief.additionalNotes || null,
        deadline: new Date(`${brief.deadline}T12:00:00.000Z`),
      },
    });

    return NextResponse.json(ClientBriefReceipt.parse({ receipt }), {
      status: 201,
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch {
    return NextResponse.json({ error: 'Could not save your brief.' }, { status: 500 });
  }
}
