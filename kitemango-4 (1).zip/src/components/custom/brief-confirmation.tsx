// @polsia:user-owned — receipt-only acknowledgment, safe to reload or revisit.
'use client';

import { Check } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import {
  type ClientBriefAcknowledgement as Acknowledgement,
  ClientBriefAcknowledgement,
} from '@/lib/contracts/client-brief';

export function BriefConfirmation({ receipt }: { receipt: string }) {
  const [acknowledgement, setAcknowledgement] = useState<Acknowledgement | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let active = true;
    apiFetch(`/api/client-briefs/${encodeURIComponent(receipt)}`, {
      schema: ClientBriefAcknowledgement,
    })
      .then((result) => {
        if (active) setAcknowledgement(result);
      })
      .catch(() => {
        if (active) setNotFound(true);
      });
    return () => {
      active = false;
    };
  }, [receipt]);

  return (
    <main className="mx-auto flex min-h-[65vh] w-full max-w-3xl items-center px-4 py-12 sm:px-6">
      <Card className="w-full overflow-hidden border-primary/20 shadow-xl shadow-primary/5">
        <CardContent className="p-6 text-center sm:p-12">
          {acknowledgement ? (
            <>
              <span className="mx-auto flex size-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Check className="size-8" aria-hidden="true" />
              </span>
              <p className="mt-6 text-sm font-semibold uppercase tracking-[0.18em] text-primary">
                KiteMango · Brief received
              </p>
              <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
                Your brief is safely recorded.
              </h1>
              <p className="mx-auto mt-4 max-w-lg leading-7 text-muted-foreground">
                This page is your receipt that KiteMango received your client brief. You can return
                to this link later to see this confirmation again.
              </p>
              <p className="mt-6 text-sm text-muted-foreground">
                Submitted{' '}
                {new Intl.DateTimeFormat('en-IN', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                }).format(new Date(acknowledgement.submittedAt))}
              </p>
              <Button asChild variant="outline" className="mt-8 rounded-full">
                <Link href="/">Back to KiteMango</Link>
              </Button>
            </>
          ) : notFound ? (
            <>
              <h1 className="text-3xl font-bold tracking-tight">
                We could not find this confirmation.
              </h1>
              <p className="mx-auto mt-4 max-w-lg leading-7 text-muted-foreground">
                Check that you opened the full receipt link. No brief details are shown on this
                page.
              </p>
              <Button asChild className="mt-8 rounded-full">
                <Link href="/brief">Start a client brief</Link>
              </Button>
            </>
          ) : (
            <output className="text-muted-foreground">Checking your confirmation…</output>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
