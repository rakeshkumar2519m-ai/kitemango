// @polsia:user-owned — responsive public brief form and submission island.
'use client';

import { ArrowRight, Store } from 'lucide-react';
import { type FormEvent, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { apiFetch } from '@/lib/api-client';
import {
  ClientBriefCreate,
  ClientBriefReceipt,
  type ClientBriefCreate as ClientBriefValues,
  clientBriefChannels,
  clientBriefContentNeeds,
  clientBriefReelAssets,
} from '@/lib/contracts/client-brief';

const initialValues: ClientBriefValues = {
  businessName: '',
  contactName: '',
  contactEmail: '',
  phone: '',
  city: '',
  businessType: '',
  goals: '',
  channels: [],
  contentNeeds: [],
  reelAssets: [],
  reelAssetNotes: '',
  reelAssetLink: '',
  deadline: '',
  additionalNotes: '',
};

type FieldName = keyof ClientBriefValues;
type FieldErrors = Partial<Record<FieldName | 'form', string>>;

function errorText(errors: FieldErrors, name: FieldName) {
  return errors[name] ? <p className="mt-1 text-sm text-destructive">{errors[name]}</p> : null;
}

function inputClass(hasError: boolean) {
  return hasError ? 'border-destructive focus-visible:ring-destructive' : '';
}

export function BriefForm() {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  function update(field: FieldName, value: string) {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined, form: undefined }));
  }

  function toggle(field: 'channels' | 'contentNeeds' | 'reelAssets', value: string) {
    setValues((current) => {
      const selected = current[field] as string[];
      const next = selected.includes(value)
        ? selected.filter((item) => item !== value)
        : [...selected, value];
      return { ...current, [field]: next };
    });
    setErrors((current) => ({ ...current, [field]: undefined, form: undefined }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrors({});
    const parsed = ClientBriefCreate.safeParse(values);
    if (!parsed.success) {
      const nextErrors: FieldErrors = {};
      for (const [field, messages] of Object.entries(parsed.error.flatten().fieldErrors)) {
        const message = messages?.[0];
        if (message) nextErrors[field as FieldName] = message;
      }
      setErrors(nextErrors);
      document.getElementById('brief-form-heading')?.scrollIntoView({ behavior: 'auto' });
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await apiFetch('/api/client-briefs', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
        schema: ClientBriefReceipt,
      });
      window.location.assign(`/brief/confirmation/${result.receipt}`);
    } catch (error) {
      const body = error instanceof Error ? error.cause : undefined;
      if (body && typeof body === 'object' && 'errors' in body) {
        const serverErrors = body.errors;
        if (serverErrors && typeof serverErrors === 'object') {
          const nextErrors: FieldErrors = {};
          for (const [field, message] of Object.entries(serverErrors)) {
            if (typeof message === 'string') nextErrors[field as FieldName] = message;
          }
          setErrors(nextErrors);
        } else {
          setErrors({ form: 'Please review your brief and try again.' });
        }
      } else {
        setErrors({ form: 'We could not save your brief. Please try again.' });
      }
      setIsSubmitting(false);
    }
  }

  const fieldClass = (name: FieldName) => inputClass(Boolean(errors[name]));

  return (
    <Card className="border-border/80 shadow-lg shadow-primary/5">
      <CardHeader className="border-b border-border/70 bg-muted/40 px-5 py-5 sm:px-8">
        <div className="flex items-start gap-3">
          <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Store className="size-5" aria-hidden="true" />
          </span>
          <div>
            <CardTitle id="brief-form-heading" className="text-xl sm:text-2xl">
              Your client brief
            </CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">
              Fields marked required need an answer.
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="px-5 py-6 sm:px-8 sm:py-8">
        <form className="space-y-9" onSubmit={submit} noValidate>
          <section aria-labelledby="business-details-heading">
            <div className="mb-5 flex items-center gap-2 border-b border-border pb-3">
              <Store className="size-4 text-primary" aria-hidden="true" />
              <h2 id="business-details-heading" className="font-semibold">
                Business details
              </h2>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label htmlFor="businessName">
                  Business name <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="businessName"
                  required
                  autoComplete="organization"
                  value={values.businessName}
                  aria-invalid={Boolean(errors.businessName)}
                  className={`mt-1.5 ${fieldClass('businessName')}`}
                  onChange={(event) => update('businessName', event.target.value)}
                />
                {errorText(errors, 'businessName')}
              </div>
              <div>
                <Label htmlFor="contactName">
                  Your name <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="contactName"
                  required
                  autoComplete="name"
                  value={values.contactName}
                  aria-invalid={Boolean(errors.contactName)}
                  className={`mt-1.5 ${fieldClass('contactName')}`}
                  onChange={(event) => update('contactName', event.target.value)}
                />
                {errorText(errors, 'contactName')}
              </div>
              <div>
                <Label htmlFor="businessType">
                  What does your business do? <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="businessType"
                  required
                  placeholder="For example, a neighbourhood bakery"
                  value={values.businessType}
                  aria-invalid={Boolean(errors.businessType)}
                  className={`mt-1.5 ${fieldClass('businessType')}`}
                  onChange={(event) => update('businessType', event.target.value)}
                />
                {errorText(errors, 'businessType')}
              </div>
              <div>
                <Label htmlFor="city">
                  City or area <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="city"
                  required
                  autoComplete="address-level2"
                  placeholder="City, neighbourhood, or service area"
                  value={values.city}
                  aria-invalid={Boolean(errors.city)}
                  className={`mt-1.5 ${fieldClass('city')}`}
                  onChange={(event) => update('city', event.target.value)}
                />
                {errorText(errors, 'city')}
              </div>
              <div>
                <Label htmlFor="phone">
                  Phone with country code <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="phone"
                  required
                  type="tel"
                  autoComplete="tel"
                  placeholder="+91 …"
                  value={values.phone}
                  aria-invalid={Boolean(errors.phone)}
                  className={`mt-1.5 ${fieldClass('phone')}`}
                  onChange={(event) => update('phone', event.target.value)}
                />
                {errorText(errors, 'phone')}
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="contactEmail">
                  Email address <span aria-hidden="true">*</span>
                </Label>
                <Input
                  id="contactEmail"
                  required
                  type="email"
                  autoComplete="email"
                  value={values.contactEmail}
                  aria-invalid={Boolean(errors.contactEmail)}
                  className={`mt-1.5 ${fieldClass('contactEmail')}`}
                  onChange={(event) => update('contactEmail', event.target.value)}
                />
                {errorText(errors, 'contactEmail')}
              </div>
            </div>
          </section>

          <section aria-labelledby="goals-heading">
            <h2 id="goals-heading" className="mb-4 border-b border-border pb-3 font-semibold">
              Goals and channels
            </h2>
            <div>
              <Label htmlFor="goals">
                What would you like your content to help with? <span aria-hidden="true">*</span>
              </Label>
              <Textarea
                id="goals"
                required
                rows={4}
                placeholder="Share an offer, goal, upcoming moment, or the customers you want to reach."
                value={values.goals}
                aria-invalid={Boolean(errors.goals)}
                className={`mt-1.5 ${fieldClass('goals')}`}
                onChange={(event) => update('goals', event.target.value)}
              />
              {errorText(errors, 'goals')}
            </div>
            <OptionGroup
              legend="Where do you want to reach customers? *"
              name="channels"
              options={clientBriefChannels}
              selected={values.channels}
              error={errors.channels}
              onToggle={(value) => toggle('channels', value)}
            />
          </section>

          <section aria-labelledby="content-heading">
            <h2 id="content-heading" className="mb-4 border-b border-border pb-3 font-semibold">
              Content and reel assets
            </h2>
            <OptionGroup
              legend="What would you like help creating? *"
              name="contentNeeds"
              options={clientBriefContentNeeds}
              selected={values.contentNeeds}
              error={errors.contentNeeds}
              onToggle={(value) => toggle('contentNeeds', value)}
            />
            <div className="mt-6">
              <OptionGroup
                legend="What reel assets can you share? *"
                name="reelAssets"
                options={clientBriefReelAssets}
                selected={values.reelAssets}
                error={errors.reelAssets}
                onToggle={(value) => toggle('reelAssets', value)}
              />
            </div>
            <div className="mt-5 grid gap-4">
              <div>
                <Label htmlFor="reelAssetNotes">
                  Tell us about your clips, photos, or brand assets
                </Label>
                <Textarea
                  id="reelAssetNotes"
                  rows={3}
                  placeholder="What footage exists, and what should a reel show?"
                  value={values.reelAssetNotes ?? ''}
                  aria-invalid={Boolean(errors.reelAssetNotes)}
                  className={`mt-1.5 ${fieldClass('reelAssetNotes')}`}
                  onChange={(event) => update('reelAssetNotes', event.target.value)}
                />
                {errorText(errors, 'reelAssetNotes')}
              </div>
              <div>
                <Label htmlFor="reelAssetLink">Optional HTTPS link to a shared asset folder</Label>
                <Input
                  id="reelAssetLink"
                  type="url"
                  placeholder="Paste a share link"
                  value={values.reelAssetLink ?? ''}
                  aria-invalid={Boolean(errors.reelAssetLink)}
                  className={`mt-1.5 ${fieldClass('reelAssetLink')}`}
                  onChange={(event) => update('reelAssetLink', event.target.value)}
                />
                {errorText(errors, 'reelAssetLink')}
                <p className="mt-1 text-xs leading-5 text-muted-foreground">
                  Set access on the link yourself. Do not include passwords or private access codes.
                </p>
              </div>
            </div>
          </section>

          <section aria-labelledby="deadline-heading">
            <h2 id="deadline-heading" className="mb-4 border-b border-border pb-3 font-semibold">
              Timing
            </h2>
            <div>
              <Label htmlFor="deadline">
                When do you need the first content? <span aria-hidden="true">*</span>
              </Label>
              <Input
                id="deadline"
                required
                type="date"
                value={values.deadline}
                aria-invalid={Boolean(errors.deadline)}
                className={`mt-1.5 ${fieldClass('deadline')}`}
                onChange={(event) => update('deadline', event.target.value)}
              />
              {errorText(errors, 'deadline')}
            </div>
            <div className="mt-5">
              <Label htmlFor="additionalNotes">Anything else we should know?</Label>
              <Textarea
                id="additionalNotes"
                rows={3}
                placeholder="Optional details about your offer, style, or audience."
                value={values.additionalNotes ?? ''}
                aria-invalid={Boolean(errors.additionalNotes)}
                className={`mt-1.5 ${fieldClass('additionalNotes')}`}
                onChange={(event) => update('additionalNotes', event.target.value)}
              />
              {errorText(errors, 'additionalNotes')}
            </div>
          </section>

          {errors.form ? (
            <p
              role="alert"
              className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
            >
              {errors.form}
            </p>
          ) : null}
          <div className="flex flex-col gap-3 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-sm text-xs leading-5 text-muted-foreground">
              Your submission is stored for KiteMango. Its receipt confirms only that your brief was
              received.
            </p>
            <Button
              type="submit"
              size="lg"
              disabled={isSubmitting}
              className="w-full shrink-0 rounded-full sm:w-auto"
            >
              {isSubmitting ? 'Saving brief…' : 'Send my brief'}
              <ArrowRight aria-hidden="true" />
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

type OptionGroupProps = {
  legend: string;
  name: string;
  options: readonly string[];
  selected: readonly string[];
  error?: string;
  onToggle: (value: string) => void;
};

function OptionGroup({ legend, name, options, selected, error, onToggle }: OptionGroupProps) {
  return (
    <fieldset className="mt-5" aria-describedby={error ? `${name}-error` : undefined}>
      <legend className="text-sm font-medium">{legend}</legend>
      <div className="mt-2 grid gap-2 sm:grid-cols-2">
        {options.map((option) => {
          const id = `${name}-${option.toLowerCase().replaceAll(/[^a-z0-9]+/g, '-')}`;
          const checked = selected.includes(option);
          return (
            <label
              key={option}
              htmlFor={id}
              className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 text-sm transition-colors ${checked ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/60'}`}
            >
              <input
                id={id}
                type="checkbox"
                name={name}
                value={option}
                checked={checked}
                onChange={() => onToggle(option)}
                className="size-4 shrink-0 accent-primary"
              />
              <span>{option}</span>
            </label>
          );
        })}
      </div>
      {error ? (
        <p id={`${name}-error`} className="mt-1 text-sm text-destructive">
          {error}
        </p>
      ) : null}
    </fieldset>
  );
}
