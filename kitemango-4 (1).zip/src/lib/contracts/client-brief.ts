// @polsia:user-owned — shared client brief contract for the form and API routes.
import { z } from 'zod';

export const clientBriefChannels = [
  'Instagram',
  'Facebook',
  'WhatsApp',
  'YouTube',
  'Google Business Profile',
  'LinkedIn',
  'Other',
] as const;

export const clientBriefContentNeeds = [
  'Promotional reels',
  'Feed posts',
  'Stories',
  'Offer or event posters',
  'Captions and copy',
  'A monthly content plan',
  'I am still deciding',
] as const;

export const clientBriefReelAssets = [
  'Video clips',
  'Product or service photos',
  'Logo or brand kit',
  'I do not have assets yet',
  'Other',
] as const;

const httpsLink = z
  .string()
  .trim()
  .max(1000, 'Keep the asset link under 1,000 characters.')
  .refine((value) => value === '' || /^https:\/\//i.test(value), 'Use an HTTPS share link.');

export const ClientBriefCreate = z
  .object({
    businessName: z.string().trim().min(2, 'Enter your business name.').max(120),
    contactName: z.string().trim().min(2, 'Enter your name.').max(120),
    contactEmail: z.string().trim().email('Enter a valid email address.').max(254),
    phone: z.string().trim().min(8, 'Enter a phone number with its country code.').max(24),
    city: z.string().trim().min(2, 'Enter your city or area.').max(120),
    businessType: z.string().trim().min(2, 'Tell us what your business does.').max(160),
    goals: z.string().trim().min(10, 'Add a little more detail about your goal.').max(2000),
    channels: z.array(z.enum(clientBriefChannels)).min(1, 'Choose at least one channel.'),
    contentNeeds: z
      .array(z.enum(clientBriefContentNeeds))
      .min(1, 'Choose at least one content need.'),
    reelAssets: z.array(z.enum(clientBriefReelAssets)).min(1, 'Choose an asset option.'),
    reelAssetNotes: z.string().trim().max(1500).optional(),
    reelAssetLink: httpsLink.optional(),
    deadline: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, 'Choose a deadline.')
      .refine((value) => {
        const date = new Date(`${value}T00:00:00.000Z`);
        return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
      }, 'Enter a valid date.'),
    additionalNotes: z.string().trim().max(2000).optional(),
  })
  .strict();

export const ClientBriefReceipt = z.object({
  receipt: z.string().regex(/^[a-f0-9]{64}$/),
});

export const ClientBriefAcknowledgement = z.object({
  acknowledged: z.literal(true),
  submittedAt: z.string().datetime(),
});

export type ClientBriefCreate = z.infer<typeof ClientBriefCreate>;
export type ClientBriefReceipt = z.infer<typeof ClientBriefReceipt>;
export type ClientBriefAcknowledgement = z.infer<typeof ClientBriefAcknowledgement>;
